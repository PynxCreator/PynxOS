import os
import time
import sys

while True:
  u = input("root@localhost:~# ")
  if u =='help' or 'Help':
    print("'help' prints this message")
    print("'install-from-git' installs something from github")
  elif u =='install-from-git':
    url = input("enter url: ")
    os.system('git clone {}'.format(url))
  elif u =='nmap':
    nmap = input("enter ip to scan: ")
    os.system('nmap {}'.format))