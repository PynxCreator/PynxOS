#!/bin/sh
cd PynxOS
python main.py